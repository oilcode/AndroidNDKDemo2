//----------------------------------------------------------------
#include "GGUIInputState.h"
//----------------------------------------------------------------
int GGUIInputState::m_nWindoeID_CursorInWindowRect = -1;
int GGUIInputState::m_nWindoeID_CursorDrag = -1;
float GGUIInputState::m_fLastCursorPosX = 0.0f;
float GGUIInputState::m_fLastCursorPosY = 0.0f;
//----------------------------------------------------------------
