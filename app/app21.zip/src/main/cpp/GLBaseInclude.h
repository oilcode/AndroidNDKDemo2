//--------------------------------------------------------------------------------------------------
#ifndef _GLBaseInclude_h_
#define _GLBaseInclude_h_
//--------------------------------------------------------------------------------------------------
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
//--------------------------------------------------------------------------------------------------
#include "SoCodeBaseInclude.h"
#include "SoIDEOutputLog.h"
#include "SoArrayUID.h"
#include "SoArray.h"
#include "SoMessageBox.h"
#include "SoMath.h"
#include "SoFileHelp.h"
#include "SoImageHelp.h"
//--------------------------------------------------------------------------------------------------
#include "AnJava2CppStaticFunction.h"
#include "AnInputMsgDefine.h"
//--------------------------------------------------------------------------------------------------
#endif //_GLBaseInclude_h_
//--------------------------------------------------------------------------------------------------
