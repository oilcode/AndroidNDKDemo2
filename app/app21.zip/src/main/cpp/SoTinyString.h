﻿//-----------------------------------------------------------------------------
#ifndef _SoTinyString_h_
#define _SoTinyString_h_
//-----------------------------------------------------------------------------
#include "SoCodeBaseInclude.h"
//-----------------------------------------------------------------------------
//本对象中最多有多少个字符（包括结束符）。
//本对象的sizeof值是 (MaxCharCount_TinyString + 1) 。
#define MaxCharCount_TinyString 23
//-----------------------------------------------------------------------------
class SODLL SoTinyString
{
public:
	SoTinyString();
	SoTinyString(const char* pszString);
	SoTinyString(const SoTinyString& other);
	~SoTinyString();

	//注意，pszString字符串的size（包括结束符）不能大于MaxCharCount_TinyString；
	//如果大于的话，会被截断。
	//如果pszString值为NULL，则m_szBuffer被置为空字符串""。
	void SetValue(const char* pszString);
	const char* GetValue() const;
	char* GetBuffer();
	//获取有效字符的个数，不包括结束符。
	soint32 GetLength() const;
	void Clear();

	//用等号赋值操作
	void operator = (const char* pszString);
	void operator = (const SoTinyString& other);

	//<运算符的重载方法有两种：
	//1，成员函数 bool operator < (const SoTinyString& other);
	//2，全局函数 friend bool operator < (const SoTinyString& left, const SoTinyString& right);
	//这两种方法都支持这样的表达式 bool br = TinyStr1 < TinyStr2;
	//STL容器在排序时会使用到<运算符，只有第2种方法才支持STL容器。
	friend bool operator < (const SoTinyString& left, const SoTinyString& right);

private:
	char m_szBuffer[MaxCharCount_TinyString];
	soint8 m_nLength;
};
//-----------------------------------------------------------------------------
inline SoTinyString::SoTinyString()
{
	Clear();
}
//-----------------------------------------------------------------------------
inline SoTinyString::SoTinyString(const char* pszString)
{
	SetValue(pszString);
}
//-----------------------------------------------------------------------------
inline SoTinyString::SoTinyString(const SoTinyString& other)
{
	SetValue(other.GetValue());
}
//-----------------------------------------------------------------------------
inline SoTinyString::~SoTinyString()
{
	//do nothing
}
//-----------------------------------------------------------------------------
inline const char* SoTinyString::GetValue() const
{
	return m_szBuffer;
}
//-----------------------------------------------------------------------------
inline char* SoTinyString::GetBuffer()
{
	return m_szBuffer;
}
//-----------------------------------------------------------------------------
inline soint32 SoTinyString::GetLength() const
{
	return m_nLength;
}
//-----------------------------------------------------------------------------
inline void SoTinyString::Clear()
{
	m_szBuffer[0] = 0;
	m_nLength = 0;
}
//-----------------------------------------------------------------------------
inline void SoTinyString::operator = (const char* pszString)
{
	//if (pszString != 0 && (&(m_szBuffer[0]) == &(pszString[0])))
	//{
	//	//不能把自己赋值给自己
	//	return;
	//}
	//else
	//{
	//	SetValue(pszString);
	//}
	//“把自己赋值给自己”这种情况几乎不会出现；
	//即使出现，执行 SetValue() 函数也不会出错。
	//所以就不要执行if判断了。
	SetValue(pszString);
}
//-----------------------------------------------------------------------------
inline void SoTinyString::operator = (const SoTinyString& other)
{
	//if (this == &other)
	//{
	//	//不能把自己赋值给自己
	//	return;
	//}
	//else
	//{
	//	SetValue(other.GetValue());
	//}
	//“把自己赋值给自己”这种情况几乎不会出现；
	//即使出现，执行 SetValue() 函数也不会出错。
	//所以就不要执行if判断了。
	SetValue(other.GetValue());
}
//-----------------------------------------------------------------------------
#endif //_SoTinyString_h_
//-----------------------------------------------------------------------------
