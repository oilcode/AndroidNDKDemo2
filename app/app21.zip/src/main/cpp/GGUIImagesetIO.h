//----------------------------------------------------------------
#ifndef _GGUIImagesetIO_h_
#define _GGUIImagesetIO_h_
//----------------------------------------------------------------
#include "GGUIBaseInclude.h"
//----------------------------------------------------------------
class GGUIImagesetIO
{
public:
	static bool Read(const char* szImagesetName, GGUIImagesetType eType);
};
//----------------------------------------------------------------
#endif //_GGUIImagesetIO_h_
//----------------------------------------------------------------
