//----------------------------------------------------------------
#ifndef _NwLogicFlowHelp_h_
#define _NwLogicFlowHelp_h_
//----------------------------------------------------------------
bool NwLogicFlowHelp_Create();
void NwLogicFlowHelp_Release();
void NwLogicFlowHelp_Update(float fDeltaTime);
//----------------------------------------------------------------
#endif //_NwLogicFlowHelp_h_
//----------------------------------------------------------------
