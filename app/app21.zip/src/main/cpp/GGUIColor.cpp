//------------------------------------------------------------
#include "GGUIColor.h"
//------------------------------------------------------------
const GGUIColor GGUIColor_Empty(0.0f, 0.0f, 0.0f, 0.0f);
const GGUIColor GGUIColor_Black(0.0f, 0.0f, 0.0f, 1.0f);
const GGUIColor GGUIColor_White(1.0f, 1.0f, 1.0f, 1.0f);
const GGUIColor GGUIColor_Red(1.0f, 0.0f, 0.0f, 1.0f);
const GGUIColor GGUIColor_Green(0.0f, 1.0f, 0.0f, 1.0f);
const GGUIColor GGUIColor_Blue(0.0f, 0.0f, 1.0f, 1.0f);
//------------------------------------------------------------
