//-----------------------------------------------------------------------------
#include "GGUILogHelp.h"
#include "GGUIBaseInclude.h"
//-----------------------------------------------------------------------------
void GGUILogHelp::Print(const char* szDesc)
{
    SoIDEOutputLogInfo("%s", szDesc);
    SoMessageBox("GGUI", szDesc);
}
//-----------------------------------------------------------------------------
void GGUILogHelp::Printf(const char* szFormat, ...)
{
	va_list klist;
	va_start(klist, szFormat);
    const char* szDesc = SoStrFmtByVaList(szFormat, &klist);
	va_end(klist);
	SoIDEOutputLogInfo("%s", szDesc);
	SoMessageBox("GGUI", szDesc);
}
//-----------------------------------------------------------------------------
