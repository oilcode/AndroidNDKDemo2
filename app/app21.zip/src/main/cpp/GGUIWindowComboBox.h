//------------------------------------------------------------
#ifndef _GGUIWindowComboBox_h_
#define _GGUIWindowComboBox_h_
//------------------------------------------------------------
#include "GGUIWindowContainer.h"
//------------------------------------------------------------
class GGUIWindowComboBox : public GGUIWindowContainer
{

};
//------------------------------------------------------------
#endif //_GGUIWindowComboBox_h_
//------------------------------------------------------------
