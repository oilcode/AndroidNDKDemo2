package com.ggui.swoosh.fidemo;

public class Cpp2JavaLoadAllLib
{
    public static void LoadAllLib()
    {
        Cpp2JavaLibNative.LoadLib();
    }
}
